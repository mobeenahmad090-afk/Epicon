export const reviews = [
  {
    name: "Ali Khan",
    location: "Lahore",
    comment: "These mangoes are the juiciest I’ve ever had. Arrived fresh and fast!",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
  },
  {
    name: "Ayesha Sheikh",
    location: "Karachi",
    comment: "Loved the quality and packaging. Will order again for sure!",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
  },
  {
    name: "Usman Tariq",
    location: "Islamabad",
    comment: "Excellent taste and delivery service. Highly recommended!",
    image: "https://randomuser.me/api/portraits/men/65.jpg",
  },
  {
    name: "Fatima Noor",
    location: "Multan",
    comment: "I sent a box to my parents and they loved it!",
    image: "https://randomuser.me/api/portraits/women/58.jpg",
  },
  {
    name: "Bilal Ahmed",
    location: "Faisalabad",
    comment: "Very fresh mangoes and nice customer service!",
    image: "https://randomuser.me/api/portraits/men/76.jpg",
  },
];

export default reviews;
